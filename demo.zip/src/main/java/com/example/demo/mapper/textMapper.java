package com.example.demo.mapper;

import com.example.demo.domin.StudentInfo;
import com.example.demo.domin.test;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface textMapper {
    public List<StudentInfo> selectStudentInfo(@Param("id") int id,@Param("name") String name);
    public List<StudentInfo> selectStudentInfo1(@Param("m") int m);
    public List<StudentInfo> selectStudentInfo2(@Param("id") int id,@Param("name") String name);
    public List<StudentInfo> selectStudentInfo3();
    public List<StudentInfo> selectStudentInfo4(@Param("n") StudentInfo n);
}
