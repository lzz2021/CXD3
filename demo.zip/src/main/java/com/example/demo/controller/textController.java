package com.example.demo.controller;

import com.example.demo.domin.StudentInfo;
import com.example.demo.domin.text;
import com.example.demo.service.textService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@Controller
@ResponseBody
@RequestMapping("/text")
public class textController {

    @Autowired
    private textService textService;

    @PostMapping("/text1")
    public List<StudentInfo> text1(@RequestBody text i){
        return textService.opatationString(i);
    }

    @GetMapping("/text2")
    public List<StudentInfo> text2(int m){
        return textService.opatationString1(m);
    }
    @GetMapping("/text3")
    public List<StudentInfo> text3(int id, String name){
        return textService.opatationString2(id,name);
    }

    @GetMapping("/text4")
    public List<StudentInfo> text4(){
        return textService.opatationString3();
    }
    @PostMapping("/text5")
    public List<StudentInfo> text5(@RequestBody StudentInfo n){
        return textService.opatationString4(n);
    }

}
