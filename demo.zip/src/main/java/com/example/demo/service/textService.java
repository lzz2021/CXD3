package com.example.demo.service;

import com.example.demo.domin.StudentInfo;
import com.example.demo.domin.text;

import java.util.List;

public interface textService {
    public List<StudentInfo> opatationString(text i);
    public List<StudentInfo> opatationString1(int m);
    public List<StudentInfo> opatationString2(int id, String name);
    public List<StudentInfo> opatationString3();
    public List<StudentInfo> opatationString4(StudentInfo n);
}
