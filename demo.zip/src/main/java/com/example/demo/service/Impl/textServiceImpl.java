package com.example.demo.service.Impl;

import com.example.demo.domin.StudentInfo;
import com.example.demo.domin.text;
import com.example.demo.mapper.textMapper;
import com.example.demo.service.textService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class textServiceImpl implements textService {

    @Autowired
    private textMapper textMapper;

    public List<StudentInfo> opatationString(text i){
        return textMapper.selectStudentInfo(i.getId(),i.getName());
    }
    public List<StudentInfo> opatationString1(int m){
        return textMapper.selectStudentInfo1(m);
    }
    public List<StudentInfo> opatationString2(int id, String name){
        return textMapper.selectStudentInfo2(id,name);
    }
    public List<StudentInfo> opatationString3(){
        return textMapper.selectStudentInfo3();
    }
    public List<StudentInfo> opatationString4(StudentInfo n){
        return textMapper.selectStudentInfo4(n);
    }

}
