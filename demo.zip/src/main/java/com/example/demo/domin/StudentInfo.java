package com.example.demo.domin;


public class StudentInfo {

  private long studentId;
  private String studentName;
  private long studentHigh;
  private long studentWeight;
  private String studentCloth;
  private long agell;


  public long getStudentId() {
    return studentId;
  }

  public void setStudentId(long studentId) {
    this.studentId = studentId;
  }


  public String getStudentName() {
    return studentName;
  }

  public void setStudentName(String studentName) {
    this.studentName = studentName;
  }


  public long getStudentHigh() {
    return studentHigh;
  }

  public void setStudentHigh(long studentHigh) {
    this.studentHigh = studentHigh;
  }


  public long getStudentWeight() {
    return studentWeight;
  }

  public void setStudentWeight(long studentWeight) {
    this.studentWeight = studentWeight;
  }


  public String getStudentCloth() {
    return studentCloth;
  }

  public void setStudentCloth(String studentCloth) {
    this.studentCloth = studentCloth;
  }


  public long getAgell() {
    return agell;
  }

  public void setAgell(long agell) {
    this.agell = agell;
  }

}
