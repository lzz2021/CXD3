package com.example.demo.domin;

import org.springframework.stereotype.Component;

public class test {
    private String[] i;

    private int pageNum;

    private int pageSize;

    public String[] getI() {
        return i;
    }

    public void setI(String[] i) {
        this.i = i;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
