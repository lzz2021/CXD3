package com.example.text1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Text1Application {

    public static void main(String[] args) {
        SpringApplication.run(Text1Application.class, args);
    }

}
